CATATAN PRO - Firebase Login & Cloud Sync

1. Firebase Console > Authentication > Sign-in method:
   aktifkan Email/Password dan Google.
2. Pastikan aplikasi Android terdaftar dengan package:
   com.rewinding.catatanpro
3. Tambahkan SHA-1 dan SHA-256 sertifikat debug dari proses build ke
   Firebase Console > Project settings > Your apps. Google Sign-In
   membutuhkan fingerprint yang cocok.
4. Firebase Console > Firestore Database > Rules:
   salin isi file firestore.rules lalu klik Publish.
5. Simpan google-services.json di android/app/ (sudah disertakan).

Aplikasi menyimpan data lokal dan menyinkronkan catatan per UID akun ke
Firestore pada users/{uid}/records/{recordId}. Setiap akun hanya dapat
membaca dan menulis catatannya sendiri sesuai aturan Firestore.

Catatan: setelah build pertama, ambil SHA-1/SHA-256 dari log Gradle
atau jalankan ./gradlew signingReport, lalu daftarkan di Firebase.
