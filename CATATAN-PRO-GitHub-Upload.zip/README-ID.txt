CATATAN PRO - Paket sumber aplikasi Android

Isi:
- android/: proyek Android Studio (WebView) yang memuat aplikasi CATATAN PRO.
- android/app/src/main/assets/index.html: aplikasi dengan template REWINDING PRO.

Fitur:
- Tambah, edit, hapus catatan.
- Pencarian berdasarkan nama, pelanggan, jenis/merek motor, isi catatan dan data winding.
- Form Data Motor, Spesifikasi, DATA WINDING (Slot, Group, C/Group, C/Span, Conductor, Turn, Wire size, Kawat bekas), CONNECTION (kelompok coil, ujung Awal/Akhir, terminal U/X dan diagram), Catatan.
- Data disimpan secara lokal pada perangkat melalui localStorage.

Cara membuat APK:
1. Instal Android Studio versi terbaru dan Android SDK Platform 35.
2. Buka folder android sebagai project di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya tersedia di android/app/build/outputs/apk/debug/app-debug.apk.

Catatan penting:
Paket ini adalah source project Android, bukan APK yang sudah dikompilasi. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle, jadi file APK belum dapat dibangun di sini. Data tersimpan pada perangkat yang menjalankan aplikasi dan tidak otomatis tersinkron ke perangkat lain.

Build APK otomatis melalui GitHub Actions:
1. Upload seluruh folder proyek ini ke repository GitHub.
2. Buka tab Actions pada repository.
3. Jalankan workflow "Build CATATAN PRO APK" (Run workflow), atau push ke branch main/master.
4. Setelah selesai, buka hasil workflow dan unduh artifact "CATATAN-PRO-debug-apk".
5. Ekstrak artifact; file app-debug.apk dapat dipindahkan ke HP Android dan diinstal.
